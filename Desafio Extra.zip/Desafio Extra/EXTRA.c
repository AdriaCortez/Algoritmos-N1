#include <stdio.h>

// Fun��o para validar se a nota est� dentro do limite permitido
int validar_nota(float nota, float limite_superior) {
    if (nota >= 0 && nota <= limite_superior) {
        return 1; // Nota v�lida
    }
    return 0;     // Nota inv�lida
}

// Fun��o principal onde o programa roda
int main() {
    float N1, N2, PPD, EU = 0, N3 = 0, nota_final;
    int fez_exame, fez_N3;

    // Ler a nota N1 e verificar se est� no intervalo de 0 a 4,5
    printf("Digite a nota N1 (Entre 0 a 4.5): ");
    scanf("%f", &N1);
    if (!validar_nota(N1, 4.5)) {
        printf("Erro: A nota N1 nao esta no intervalo permitido.\n");
        return 3; // C�digo de erro 3 se a nota for inv�lida
    }

    // Ler a nota N2 e verificar se est� no intervalo de 0 a 4,5
    printf("Digite a nota N2 (Entre 0 a 4.5): ");
    scanf("%f", &N2);
    if (!validar_nota(N2, 4.5)) {
        printf("Erro: A nota N2 nao esta no intervalo permitido.\n");
        return 3; // C�digo de erro 3 se a nota for inv�lida
    }

    // Ler a nota do PPD (Projeto de Pr�tica Discente) e validar se � 0 ou 1
    printf("Digite a nota do PPD (Entre 0 a 1): ");
    scanf("%f", &PPD);
    if (!validar_nota(PPD, 1)) {
        printf("Erro: A nota do PPD nao esta no intervalo permitido.\n");
        return 3; // C�digo de erro 3 se a nota for inv�lida
    }

    // Perguntar se o aluno fez o Exame Unificado (EU)
    printf("Realizou o Exame Unificado? (0 para nao, 1 para sim): ");
    scanf("%d", &fez_exame);
    if (fez_exame == 1) {
        // Ler a nota do Exame Unificado e validar
        printf("Digite a nota do Exame Unificado (Entre 0 a 1): ");
        scanf("%f", &EU);
        if (!validar_nota(EU, 1)) {
            printf("Erro: A nota do Exame Unificado nao esta no intervalo permitido.\n");
            return 3; // C�digo de erro 3 se a nota for inv�lida
        }
    }

    // Perguntar se o aluno fez a prova N3
    printf("Realizou 	a N3? (0 para nao, 1 para sim): ");
    scanf("%d", &fez_N3);
    if (fez_N3 == 1) {
        // Ler a nota N3 e validar
        printf("Digite a nota N3 (Entre 0 a 4.5): ");
        scanf("%f", &N3);
        if (!validar_nota(N3, 4.5)) {
            printf("Erro: A nota N3 nao esta no intervalo permitido.\n");
            return 3; // C�digo de erro 3 se a nota for inv�lida
        }

        // Substituir a menor entre N1 e N2 pela N3 se a N3 for maior
        if (N3 > N1 && N1 <= N2) {
            N1 = N3;
        } else if (N3 > N2 && N2 <= N1) {
            N2 = N3;
        }
    }

    // Calcular a nota final somando N1, N2, PPD e EU
    nota_final = N1 + N2 + PPD + EU;

    // Se a nota final passar de 10, limitar para 10
    if (nota_final > 10) {
        nota_final = 10;
    }

    // Mostrar a nota final
    printf("Sua nota final �: %.2f\n", nota_final);

    // Verificar se o aluno foi aprovado ou reprovado
    if (nota_final >= 6) {
        printf("Voc� foi aprovado!\n");
    } else {
        printf("Voc� foi reprovado.\n");
    }

    return 0;
}

