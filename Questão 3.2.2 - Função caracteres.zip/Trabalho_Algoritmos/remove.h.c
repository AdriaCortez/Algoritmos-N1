#ifndef REMOVE_H
#define REMOVE_H

int func_val(int x, int b);

#endif /* REMOVE_H */
